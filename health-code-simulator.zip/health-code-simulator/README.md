# health-code-simulator

## Build

### Build for production

```shell
npm i -g uglify-js clean-css-cli html-minifier
make build
```

### Launch local server

Requires python3.

```shell
make serve
```
